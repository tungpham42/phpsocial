<?php
// Theme Name
$name = 'Tung';

// Theme Author
$author = 'Tung Pham';

// Theme URL
$url = 'https://github.com/gentlemandesigns/phpSocial-Goagal';

// Theme Version
$version = '5.4.0';
?>
