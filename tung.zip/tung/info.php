<?php
// Theme Name
$name = 'Tung';

// Theme Author
$author = 'Tung Pham';

// Theme URL
$url = 'https://github.com/tungpham42/phpsocial';

// Theme Version
$version = '5.4.0';
?>
